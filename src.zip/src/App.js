import React from 'react'
import {
  Route,
  BrowserRouter as Router,
  Switch
} from "react-router-dom";
import home from './home';
import Player from './Player';
import './App.css';

function App() {
  return (
    <Router>
    <Switch>
    <Route exact path="/" Component={home}></Route>
    <Route path="/player/:id" Component={Player}></Route>
    </Switch>
</Router>
  );
}

export default App;
