import React from 'react';
function Footer() {
    return (
        <footer>
        A Website made by Shivangi Sharma
            &copy; 2020, Shivangi. All rights reserved.
            
        </footer>
    );
}
export default Footer;