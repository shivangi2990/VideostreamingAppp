import React from 'react';
function Header() {
    return (
        <header>
            VideoStreaming Site
        </header>
    );
}
export default Header;