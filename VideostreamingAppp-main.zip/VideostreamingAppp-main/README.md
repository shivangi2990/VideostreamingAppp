# VideostreamingAppp
p a video streaming website, in which users can select a video from the home screen and stream it to the video player. A user can like and share the video and can also see how many likes and views have the video received. A user can see a comment section on the video page, for all comments and its replies.
